import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Generator {

    static int TEST_CASES = 3;

    public static void main(String[] args) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("src/public/custom.in"));
        writer.write(TEST_CASES + "\n");
        for (int t = 0; t < TEST_CASES; t++) {
            Random random = new Random();

            int n = 20;
            int m = random.nextInt(n * (n - 1) / 2) + 1;
            int k = 1;
            int l = 1;

            ArrayList<Integer> vertices = IntStream.rangeClosed(0, n - 1).boxed().collect(Collectors.toCollection(ArrayList::new));
            Collections.shuffle(vertices);

            ArrayList<Integer> edges = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                for (int j = i + 1; j < n; j++) {
                    edges.add(i * n + j);
                }
            }
            Collections.shuffle(edges);

            // first line
            writer.write(n + " " + m + " " + k + " " + l + "\n");

            // second line
            for (int i = 0; i < n - 1; i++) {
                boolean temp = true;
                for (int j = k; j < k + l; j++) {
                    if (vertices.get(j) == i) {
                        writer.write((random.nextInt(n) + 1) + " ");
                        temp = false;
                        break;
                    }
                }
                if (temp)
                    writer.write((random.nextInt(n) * 10 + 1) + " ");
            }
            writer.write((random.nextInt(n) * 10 + 1) + "\n");

            // third line
            for (int i = 0; i < k - 1; i++) {
                writer.write(vertices.get(i) + " ");
            }
            writer.write(vertices.get(k - 1) + "\n");

            // fourth line
            for (int i = k; i < k + l - 1; i++) {
                writer.write(vertices.get(i) + " ");
            }
            writer.write(vertices.get(k + l - 1) + "\n");

            // edges
            for (int i = 0; i < m; i++) {
                int edge = edges.get(i);
                writer.write(edge / n + " " + edge % n + " " + (random.nextInt(100) + 1) + "\n");
            }
        }
        writer.close();
    }

}
