import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SolutionPartial {

    static Scanner in, out;
    static boolean resultCorrect = true;
    static int count = 0;

    static void printResult(String result) {
        String expected = out.next();
        if (!expected.equals(result)) {
            resultCorrect = false;
            System.out.println("\u001B[31m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[31m(" + count + ") Your output:\t" + result + "\u001B[0m");
        } else {
            System.out.println("\u001B[32m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[32m(" + count + ") Your output:\t" + result + "\u001B[0m");
        }
        count++;
    }

    public static void main(String[] args) throws FileNotFoundException {
        String fileName = "src/public/test1";

        File input = new File(fileName + ".in");
        File output = new File(fileName + ".out");

        in = new Scanner(input);
        out = new Scanner(output);

        resultCorrect = true;
        count = 0;

        long start = System.currentTimeMillis();
        int t = in.nextInt();
        for (int i = 0; i < t; i++) {
            testCase();
        }
        long end = System.currentTimeMillis();

        if (resultCorrect) System.out.println("PASSED");
        else System.out.println("FAILED");
        System.out.println("TIME: " + (end - start) + "ms");
    }

    // ENTER YOUR CODE HERE -----------------------------------------------------------------------
    // ONLY WORKS FOR TEST 1
    public static void testCase() {
        int n = in.nextInt();
        int m = in.nextInt();
        int k = in.nextInt();
        int l = in.nextInt();

        // create the graph: an ingoing/outgoing vertex for each router + source and sink = 2n + 2 nodes
        Algorithms.Graph graph = new Algorithms.Graph(2 * n);
        int start, end;

        // save the capacities for later and add the edge between the ingoing and the outgoing vertex
        int[] r = new int[n];
        for (int i = 0; i < n; i++) {
            r[i] = in.nextInt();
            graph.addEdge(i, n + i, r[i]);
        }

        // save the source
        start = in.nextInt();

        // save the sink
        end = in.nextInt();

        // add the remaining edges
        for (int i = 0; i < m; i++) {
            graph.addEdge(n + in.nextInt(), in.nextInt(), in.nextInt());
        }

        if (graph.computeMaximumFlow(start, n + end) == r[end])
            printResult("YES");
        else
            printResult("NO");
    }

}