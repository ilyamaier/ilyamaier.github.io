import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SolutionWithoutSplitting {

    static Scanner in, out;
    static boolean resultCorrect = true;
    static int count = 0;

    static void printResult(String result) {
        String expected = out.next();
        if (!expected.equals(result)) {
            resultCorrect = false;
            System.out.println("\u001B[31m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[31m(" + count + ") Your output:\t" + result + "\u001B[0m");
        } else {
            System.out.println("\u001B[32m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[32m(" + count + ") Your output:\t" + result + "\u001B[0m");
        }
        count++;
    }

    public static void main(String[] args) throws FileNotFoundException {
        String fileName = "src/public/test2";

        File input = new File(fileName + ".in");
        File output = new File(fileName + ".out");

        in = new Scanner(input);
        out = new Scanner(output);

        resultCorrect = true;
        count = 0;

        long start = System.currentTimeMillis();
        int t = in.nextInt();
        for (int i = 0; i < t; i++) {
            testCase();
        }
        long end = System.currentTimeMillis();

        if (resultCorrect) System.out.println("PASSED");
        else System.out.println("FAILED");
        System.out.println("TIME: " + (end - start) + "ms");
    }

    // ENTER YOUR CODE HERE -----------------------------------------------------------------------
    public static void testCase() {
        int n = in.nextInt();
        int m = in.nextInt();
        int k = in.nextInt();
        int l = in.nextInt();

        // create the graph: an ingoing/outgoing vertex for each router + source and sink = 2n + 2 nodes
        Algorithms.Graph graph = new Algorithms.Graph(n + 2);
        int start = n;
        int end = n + 1;

        // save the capacities for later
        int[] r = new int[n];
        for (int i = 0; i < n; i++) {
            r[i] = in.nextInt();
        }

        // add the edges from source to the friends' routers with their respective capacity
        for (int i = 0; i < k; i++) {
            int temp = in.nextInt();
            graph.addEdge(start, temp, r[temp]);
        }

        // add the edges from bots' routers nodes to the sink with their respective capacities
        // sum up all the capacities to know how big the flow should be
        int totalFlowCap = 0;
        for (int i = 0; i < l; i++) {
            int temp = in.nextInt();
            graph.addEdge(temp, end, r[temp]);
            totalFlowCap += r[temp];
        }

        // add the remaining edges
        for (int i = 0; i < m; i++) {
            graph.addEdge(in.nextInt(), in.nextInt(), in.nextInt());
        }

        if (graph.computeMaximumFlow(start, end) == totalFlowCap)
            printResult("YES");
        else
            printResult("NO");
    }

}