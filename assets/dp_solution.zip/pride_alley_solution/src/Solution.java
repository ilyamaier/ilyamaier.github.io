import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

class Solution {

    static Scanner in, out;
    static boolean resultCorrect = true;
    static int count = 0;

    static void printResult(double result) {
        double expected = out.nextDouble();
        if (Math.abs(expected - result) > 0.001) {
            resultCorrect = false;
            System.out.println("\u001B[31m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[31m(" + count + ") Your output:\t" + result + "\u001B[0m");
        } else {
            System.out.println("\u001B[32m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[32m(" + count + ") Your output:\t" + result + "\u001B[0m");
        }
        count++;
    }

    public static void main(String[] args) throws FileNotFoundException {
        String fileName = "src/public/sample";

        File input = new File(fileName + ".in");
        File output = new File(fileName + ".out");

        in = new Scanner(input);
        out = new Scanner(output);

        resultCorrect = true;
        count = 0;

        long start = System.currentTimeMillis();
        int t = in.nextInt();
        for (int i = 0; i < t; i++) {
            testCase();
        }
        long end = System.currentTimeMillis();

        if (resultCorrect) System.out.println("PASSED");
        else System.out.println("FAILED");
        System.out.println("TIME: " + (end - start) + "ms");
    }

    static int n, m;
    static double[] prob;
    static double[][] dp;

    // ENTER YOUR CODE HERE -----------------------------------------------------------------------
    public static void testCase() {
        // Read the input and initialize the memoization array
        n = in.nextInt();
        m = in.nextInt();

        prob = new double[n];
        for (int i = 0; i < n; i++) {
            prob[i] = in.nextDouble();
        }

        dp = new double[n + 1][m + 1];
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= m; j++) {
                dp[i][j] = -1;
            }
        }

        // recursion + memoization
        printResult(solve(0, m));
    }

    /* solve(currentStore, minutesLeft)
       = Expected number of pride logos if you start your walk
       at currentStore and have minutesLeft minutes left

       To find: solve(0, m)
    */
    static double solve(int currentStore, int minutesLeft) {
        if (minutesLeft == 0 || currentStore >= n) return 0; // you are done with the walk

        // check if already memoized
        if (dp[currentStore][minutesLeft] != -1) return dp[currentStore][minutesLeft];

        // either currentStore has put up a pride logo, and we move on to the next one
        // or not, so we go to the store i + 2
        // either way, one minute is now gone
        double result = prob[currentStore] * (1 + solve(currentStore + 1, minutesLeft - 1))
                + (1 - prob[currentStore]) * solve(currentStore + 2, minutesLeft - 1);

        // memoize
        dp[currentStore][minutesLeft] = result;

        return result;
    }

}