import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

class Main {

    static Scanner in, out;
    static boolean resultCorrect = true;
    static int count = 0;

    static void printResult(double result) {
        double expected = out.nextDouble();
        if (Math.abs(expected - result) > 0.001) {
            resultCorrect = false;
            System.out.println("\u001B[31m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[31m(" + count + ") Your output:\t" + result + "\u001B[0m");
        } else {
            System.out.println("\u001B[32m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[32m(" + count + ") Your output:\t" + result + "\u001B[0m");
        }
        count++;
    }

    public static void main(String[] args) throws FileNotFoundException {
        String fileName = "src/public/test1";

        File input = new File(fileName + ".in");
        File output = new File(fileName + ".out");

        in = new Scanner(input);
        out = new Scanner(output);

        resultCorrect = true;
        count = 0;

        long start = System.currentTimeMillis();
        int t = in.nextInt();
        for (int i = 0; i < t; i++) {
            testCase();
        }
        long end = System.currentTimeMillis();

        if (resultCorrect) System.out.println("PASSED");
        else System.out.println("FAILED");
        System.out.println("TIME: " + (end - start) + "ms");
    }

    // ENTER YOUR CODE HERE -----------------------------------------------------------------------
    public static void testCase() {
        // Input using in scanner
        int n = in.nextInt();

        // Output using printResult function
        // alternatively copy test cases into custom.in / custom.out on CodeExpert
        printResult(0.0);
    }

}