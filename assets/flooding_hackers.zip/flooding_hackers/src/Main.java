import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {

    static Scanner in, out;
    static boolean resultCorrect = true;
    static int count = 0;

    static void printResult(String result) {
        String expected = out.next();
        if (!expected.equals(result)) {
            resultCorrect = false;
            System.out.println("\u001B[31m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[31m(" + count + ") Your output:\t" + result + "\u001B[0m");
        } else {
            System.out.println("\u001B[32m(" + count + ") Expected:\t\t" + expected + "\u001B[0m");
            System.out.println("\u001B[32m(" + count + ") Your output:\t" + result + "\u001B[0m");
        }
        count++;
    }

    public static void main(String[] args) throws FileNotFoundException {
        String fileName = "src/public/test1";

        File input = new File(fileName + ".in");
        File output = new File(fileName + ".out");

        in = new Scanner(input);
        out = new Scanner(output);

        resultCorrect = true;
        count = 0;

        long start = System.currentTimeMillis();
        int t = in.nextInt();
        for (int i = 0; i < t; i++) {
            testCase();
        }
        long end = System.currentTimeMillis();

        if (resultCorrect) System.out.println("PASSED");
        else System.out.println("FAILED");
        System.out.println("TIME: " + (end - start) + "ms");
    }

    // ENTER YOUR CODE HERE -----------------------------------------------------------------------
    public static void testCase() {
        int n = in.nextInt();

        printResult("YES");
    }

}